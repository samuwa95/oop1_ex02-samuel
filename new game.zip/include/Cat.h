#pragma once
#include "Location.h"
#include "io.h"

class Cat
{
public:
	Cat(Location loc);
	Location location_getter();
	void moveObject(int key); // move mouse according to key press
private:
	Location m_location;
};