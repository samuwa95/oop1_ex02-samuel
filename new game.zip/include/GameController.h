#pragma once
#include "Board.h"
#include "Location.h"
#include "Mouse.h"
#include "Cat.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <conio.h>
#include <io.h>

class GameController
{
public:
    GameController(std::string fileName);
    void SaveObjectsLocations(std::string fileName);
    void StartGame();
    int CheckFinish(); // check if the mouse got all cheeses or the cats killed the mouse
    void MoveMouse();
    void CheckMove();
    void clearScreen();
private:
    Board m_board;
    Mouse m_mouse;
    Location m_door;
    std::vector<Location> m_cheeses;
    std::vector<Cat> m_cats;
};