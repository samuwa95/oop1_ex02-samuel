#pragma once

#include "Location.h"
#include "io.h"

class Mouse
{
public:
	Mouse();
	Mouse(Location loc);
	int getLife(); // getter function to return amount of life
	Location getMouseLocation();
	void moveObject(int key); // move mouse according to key press
	void decreasedLife();

	Location GetKeyLocation();
	bool getFoundKey(); 
private:
	Location m_Mouselocation;
	Location m_keylocation;

	int m_life; // amount of hearts
	bool m_foundkey;
};