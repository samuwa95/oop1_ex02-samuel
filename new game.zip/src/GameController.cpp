#pragma once
#include "GameController.h"

GameController::GameController(std::string fileName) 
	: m_board(fileName) // m_board is object of Board class - it's activate the constructor
{
	SaveObjectsLocations(fileName);
}

void GameController::SaveObjectsLocations(std::string fileName)
{
	for (int i = 0; i < m_board.GetRows(); i++)
	{
		for (int j = 0; j < m_board.GetCols(); j++)
		{
			switch (m_board.GetBoard()[i][j])
			{
			case Characters::CAT: // keeps all cats and their locations in vector
				m_cats.push_back(Cat(Location(i, j)));
				break;
			case Characters::MOUSE: // keeps the location of the mouse in the board
				m_mouse = Mouse(Location(i, j));
				break;
			case Characters::CHEESE: // keeps all the cheeses and their location in vector
				m_cheeses.push_back(Location(i, j));
				break;
			}
		}
	}
}

void GameController::StartGame()
{
	bool game = true;
	do
	{
		Screen::resetLocation();
		clearScreen();
		Screen::resetLocation();
		switch (CheckFinish())
		{
		case 1:
			std::cout << "The mouse ate all cheeses, Well done!" << std::endl;
			game = false;
			break;
		case 2:
			std::cout << "The mouse lost all lifes, Good luck next time!" << std::endl;
			game = false;
			break;
		case 0:
			m_board.printCurrBoard(m_mouse, m_cats, m_cheeses, m_door);
			MoveMouse();
			break;
		}
	} while (game); // == true
}

int GameController::CheckFinish() // 0 - continue to play, 1 - Mouse ate all cheeses, 2 - Mouse has lost all lifes
{
	if (m_cheeses.empty())
		return 1; // win situation
	if (m_mouse.getLife() == 0)
		return 2; // lose situation
	return 0; // contiue the game
}

void GameController::MoveMouse()
{
	int tav = _getch();
	if (tav == Keys::SPECIAL_KEY || tav == 0)
	{
		tav = _getch();
		Location locate = m_mouse.getMouseLocation();
		switch (tav)
		{
		case SpecialKeys::UP:
			if (locate.row - 1 > 0)
				m_mouse.moveObject(tav);
			break;
		case SpecialKeys::DOWN:
			if (locate.row + 2 < m_board.GetRows())
				m_mouse.moveObject(tav);
			break;
		case SpecialKeys::RIGHT:
			if (locate.col + 2 < m_board.GetCols())
				m_mouse.moveObject(tav);
			break;
		case SpecialKeys::LEFT:
			if (locate.col - 1 > 0)
				m_mouse.moveObject(tav);
			break;
		}
		CheckMove();
	}
}

void GameController::CheckMove()
{
	Location locate = m_mouse.getMouseLocation();
	for (size_t i = 0; i < m_cheeses.size(); i++)
		if (locate.row == m_cheeses[i].row && locate.col == m_cheeses[i].col)
		{
			m_cheeses.erase(m_cheeses.begin() + i);
			break;
		}
	for (size_t i = 0; i < m_cats.size(); i++)
		if (locate.row == m_cats[i].location_getter().row && locate.col == m_cats[i].location_getter().col)
		{
			m_mouse.decreasedLife();
			break;
		}
}

void GameController::clearScreen()
{
	for (int i = 0; i < m_board.GetRows(); i++)
	{
		for (int j = 0; j < m_board.GetCols(); j++)
		{
			std::cout << " ";
		}
		std::cout << std::endl;
	}
}