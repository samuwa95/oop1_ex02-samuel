#pragma once
#include "Board.h"

Board::Board(std::string fileName)
{
	ReadLevelGame(fileName);
}

void Board::ReadLevelGame(std::string fileName)
{
	m_rows = 0;
	auto file = std::ifstream(fileName);

	if (!file)	//if cant find file
	{
		exit(EXIT_FAILURE);
	}

	auto line = std::string(); // arr dinamc
	std::getline(file, line);	//Read a line

	while (!line.empty())
	{
		//std::cout << line.length() << std::endl;
		//for (int i = 0; i < line.length(); i++)
		m_currBoard.push_back(line);	//each line is kept in the vector
		std::getline(file, line);
		m_rows++;
	}
	m_cols = (int)m_currBoard[0].size();
	//for (size_t i = 0; i < m_currBoard.size(); i++)
	//{
	//	int len = m_currBoard[i].size();
	//	if (cols < len)
	//		cols = len;
	//}
}

void Board::printCurrBoard(Mouse mouse, std::vector<Cat> cat, std::vector<Location> cheeses, Location door)
{
	bool print = false;
	for (int i = 0; i < m_rows; i++)
	{
		for (int j = 0; j < m_cols; j++, print = false)
		{
			if (i == 0 || j == 0 || j == m_cols - 1 || i == m_rows - 1)
			{
				std::cout << (char)Characters::HASHTAG;
				print = true;
			}
			if (!print && i == mouse.getMouseLocation().row && j == mouse.getMouseLocation().col)
			{
				std::cout << (char)Characters::MOUSE;
				print = true;
			}
			for (size_t k = 0; !print && k < cat.size(); k++)
			{
				if (i == cat[k].location_getter().row && j == cat[k].location_getter().col)
				{
					std::cout << (char)Characters::CAT;
					print = true;
					break;
				}
			}
				
			for (size_t l = 0; !print && l < cheeses.size(); l++)
			{
				if (i == cheeses[l].row && j == cheeses[l].col)
				{
					std::cout << (char)Characters::CHEESE;
					print = true;
					break;
				}
			}
			
			if (!mouse.getFoundKey())
			{
				if (!print && i == mouse.GetKeyLocation().row && j == mouse.GetKeyLocation().col)
				{
					std::cout << (char)Characters::KEY;
					print = true;
				}
				if (!print && i == door.row && j == door.col)
				{
					std::cout << (char)Characters::DOOR;
					print = true;
				}
			}
			if (!print)
				std::cout << (char)Characters::SPACE;
		}
		std::cout << std::endl;
	}
}

int Board::GetRows()
{
	return m_rows;
}

int Board::GetCols()
{
	return m_cols;
}

std::vector<std::string> Board::GetBoard()
{
	return m_currBoard;
}