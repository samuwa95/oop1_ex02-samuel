#pragma once
#include "Cat.h"

Cat::Cat(Location loc) :m_location(loc) {}

Location Cat::location_getter()
{
	return m_location;
}

void Cat::moveObject(int key)
{
	switch (key)
	{
	case SpecialKeys::UP:
		m_location.row--;
		break;
	case SpecialKeys::DOWN:
		m_location.row++;
		break;
	case SpecialKeys::LEFT:
		m_location.col--;
		break;
	case SpecialKeys::RIGHT:
		m_location.col++;
		break;
	}
}