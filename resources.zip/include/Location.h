#pragma once

struct Location
{
    int row;
    int col;
};
